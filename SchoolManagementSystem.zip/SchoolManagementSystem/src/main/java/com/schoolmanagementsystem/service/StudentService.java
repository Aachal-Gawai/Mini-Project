package com.schoolmanagementsystem.service;

import java.util.ArrayList;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.schoolmanagementsystem.model.Address;
import com.schoolmanagementsystem.model.Faculty;
import com.schoolmanagementsystem.model.Student;
import com.schoolmanagementsystem.repository.StudentRepository;

@Service
public class StudentService {
	@Autowired
	StudentRepository studentrepository;
	public List<Student> getAllStudent()   
	{  
	List<Student> student = new ArrayList<Student>();  
	studentrepository.findAll().forEach(Student -> student.add(Student));  
	return student;  
	}  
	
	public void saveOrUpdate(Student student)   
	{ 
		Faculty faculty=studentrepository.FindFaculty(student.getFaculty().getFacultyId(),student.getFaculty().getName());
		if(faculty==null) {
			studentrepository.save(student);
			
		}
			else {
				
				student.setFaculty(faculty);
				studentrepository.save(student);
				
			}

		
	}  
		
	
	public void delete(Student student)   
	{  
	studentrepository.delete(student);  
	}  

}
