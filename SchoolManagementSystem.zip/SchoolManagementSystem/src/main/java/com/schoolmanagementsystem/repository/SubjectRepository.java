package com.schoolmanagementsystem.repository;

import org.springframework.data.repository.CrudRepository;

import com.schoolmanagementsystem.model.Subject;

public interface SubjectRepository extends CrudRepository<Subject, String>{

}
