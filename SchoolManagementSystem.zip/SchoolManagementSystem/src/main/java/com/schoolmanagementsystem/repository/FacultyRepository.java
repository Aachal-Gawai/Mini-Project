package com.schoolmanagementsystem.repository;

import org.springframework.data.jpa.repository.Query;

import org.springframework.data.repository.CrudRepository;

import com.schoolmanagementsystem.model.Faculty;

public interface FacultyRepository extends CrudRepository<Faculty, Integer>{
	
}
