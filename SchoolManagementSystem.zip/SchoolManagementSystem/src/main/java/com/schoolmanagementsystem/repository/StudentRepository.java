package com.schoolmanagementsystem.repository;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.schoolmanagementsystem.model.Address;
import com.schoolmanagementsystem.model.Faculty;
import com.schoolmanagementsystem.model.Student;
import com.schoolmanagementsystem.model.Subject;

public interface StudentRepository extends CrudRepository<Student, Integer>{
	@Query("select f from Faculty f where facultyId= :facultyId and name= :name")
	public Faculty FindFaculty(int facultyId,String name);
	
}
