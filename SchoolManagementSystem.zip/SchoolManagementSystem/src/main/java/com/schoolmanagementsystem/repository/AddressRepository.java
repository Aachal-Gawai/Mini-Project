package com.schoolmanagementsystem.repository;

import org.springframework.data.repository.CrudRepository;

import com.schoolmanagementsystem.model.Address;

public interface AddressRepository extends CrudRepository<Address, String>{

}
