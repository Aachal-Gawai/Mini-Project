package com.schoolmanagementsystem.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Subject {
	@Id
	private String subjectName;
	private String facultyAllotted;
	private Integer standardAllotted;
	private Integer timeDuration;
	
	public Subject() {}
	
	public Subject(String subjectName, String facultyAllotted, Integer standardAllotted, Integer timeDuration) {
		super();
		this.subjectName = subjectName;
		this.facultyAllotted = facultyAllotted;
		this.standardAllotted = standardAllotted;
		this.timeDuration = timeDuration;
	}

	public String getSubjectName() {
		return subjectName;
	}

	public void setSubjectName(String subjectName) {
		this.subjectName = subjectName;
	}

	public String getFacultyAllotted() {
		return facultyAllotted;
	}

	public void setFacultyAllotted(String facultyAllotted) {
		this.facultyAllotted = facultyAllotted;
	}

	public Integer getStandardAllotted() {
		return standardAllotted;
	}

	public void setStandardAllotted(Integer standardAllotted) {
		this.standardAllotted = standardAllotted;
	}

	public Integer getTimeDuration() {
		return timeDuration;
	}

	public void setTimeDuration(Integer timeDuration) {
		this.timeDuration = timeDuration;
	}

}
