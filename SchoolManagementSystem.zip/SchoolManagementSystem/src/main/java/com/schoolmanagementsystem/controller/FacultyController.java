package com.schoolmanagementsystem.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.schoolmanagementsystem.model.Faculty;
import com.schoolmanagementsystem.service.FacultyService;

@RestController
public class FacultyController {
	@Autowired
	FacultyService facultyservice;
	
	@GetMapping("/faculty")  
	private List<Faculty> getAllFaculty()   
	{  
	return facultyservice.getAllFaulty();  
	}  
	
	@PostMapping("/faculty")
	private String addStudent(@RequestBody Faculty faculty) {
		facultyservice.saveOrUpdate(faculty);
		return "Successfully added";
	}
	
	@PutMapping("/faculty")
	private String updateStudent(@RequestBody Faculty faculty) {
		facultyservice.saveOrUpdate(faculty);
		return "Successfully update";
	}
	
	@DeleteMapping("/faculty")
	private String deleteStudent(@RequestBody Faculty faculty) {
		facultyservice.delete(faculty);
		return "Successfully deleted";
	}
	

}
